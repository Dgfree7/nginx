package usb

import (
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const (
	usbDevicePath = "/sys/bus/usb/devices"
)

func discoverUSBs() []*USBDevice {
	usbs := []*USBDevice{}
	filepath.Walk(usbDevicePath, func(path string, info os.FileInfo, err error) error {
		if info.Mode()|os.ModeSymlink == 0 {
			return nil
		}

		if usb, err := getUSBDevice(path); err != nil {
			fmt.Println(err)
		} else if usb != nil {
			usbs = append(usbs, usb)
		}
		return nil
	})
	return usbs
}

func getUSBDevice(path string) (*USBDevice, error) {
	var device USBDevice
	var err error

	if device.VID, err = readIntFromFile(filepath.Join(path, "idVendor")); err != nil {
		return nil, nil
	}

	if device.PID, err = readIntFromFile(filepath.Join(path, "idProduct")); err != nil {
		return nil, err
	}

	return &device, nil
}

func readIntFromFile(file string) (int, error) {
	bs, err := ioutil.ReadFile(file)
	if err != nil {
		return 0, err
	}

	num, err := strconv.ParseInt(strings.TrimSpace(string(bs)), 16, 0)
	if err != nil {
		return 0, err
	}

	return int(num), nil
}
