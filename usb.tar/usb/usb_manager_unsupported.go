package usb

import (
	"time"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/kubernetes"

	"github.com/golang/glog"
)

type usbManagerUnsupported struct {
	nodeName   types.NodeName
	kubeClient kubernetes.Interface
	duration   time.Duration
}

var _ USBManager = &usbManagerUnsupported{}

func NewUSBManagerUnsupported(nodeName types.NodeName, kubeClient kubernetes.Interface) USBManager {
	return &usbManagerUnsupported{
		nodeName:   nodeName,
		kubeClient: kubeClient,
		duration:   time.Second,
	}
}

func (m *usbManagerUnsupported) Start() error {
	go wait.PollImmediateInfinite(m.duration, m.clearResource)
	return nil
}

// clear the usb resource registered previous
func (m *usbManagerUnsupported) clearResource() (bool, error) {
	node, err := m.kubeClient.Core().Nodes().Get(string(m.nodeName), metav1.GetOptions{})
	if err != nil {
		glog.Error(err)
		return false, nil
	}

	dirty := false
	for rname := range node.Status.Capacity {
		if isUSBResourceName(rname) {
			delete(node.Status.Capacity, rname)
			dirty = true
		}
	}

	if !dirty {
		return true, nil
	}

	glog.V(4).Infof("To clear USB capacity for node %v", m.nodeName)
	if _, err := m.kubeClient.Core().Nodes().UpdateStatus(node); err != nil {
		glog.Errorf("Unable to clear USB capacity for node %q with API server: error updating node: %v", m.nodeName, err)
		return false, nil
	}

	return true, nil
}
