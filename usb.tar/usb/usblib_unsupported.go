// +build !linux

package usb

func discoverUSBs() []*USBDevice {
	panic("ListUSBDevices is Not Supported")
}
