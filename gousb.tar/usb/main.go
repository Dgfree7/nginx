package main
import (
	 "log"
	 "os"
	 pluginapi "k8s.io/kubernetes/pkg/kubelet/apis/deviceplugin/v1beta1"
 )
func main() {
	log.Println("Init encrypt_USB...")
	if err := enusb.Init(); err != nil {
		...
		select {}
	}
	defer func() { log.Println("close encrypt_USB returned:", enusb.Close()) }()
	
	log.Println("Fetching devices.")
	if len(getUsbs()) == 0 {
		log.Println("No usb devices found. Waiting indefinitely.")
		select {}
	}
	
	log.Println("Starting USB-FS watcher.")
	watcher, err := newUSBFSWatcher(pluginapi.DevicePluginPath)
	if err != nil {
		log.Println("Failed to created USB-FS watcher.")
		os.Exit(1)
	}
	defer watcher.Close()
	
	log.Println("Starting OS watcher.")
	sigs := newOSWatcher(syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
	restart := true 
	var devicePlugin *USBDevicePlugin

L:
    for {
		if restart {
			if devicePlugin != nil {
				devicePlugin.Stop()
			}
			devicePlugin = NewUSBDevicePlugin()
			if err := devicePlugin.Serve(); err != nil {
				log.Println("Could not contact Kubelet, retrying. Did you enable the device plugin feature gate? tips: --args")
			} else {
				restart = false
			}
		}
		select {
		case event := <-watcher.Events:
			if event.Name == pluginapi.KubeletSocket && event.Op&fsnotify.Create == fsnotify.Create {
				log.Printf("inotify: %s created, restarting.", pluginapi.KubeletSocket)
				restart = true
			}

		case err := <-watcher.Errors:
			log.Printf("inotify: %s", err)

		case s := <-sigs:
			switch s {
			case syscall.SIGHUP:
				log.Println("Received SIGHUP, restarting.")
				restart = true
			default:
				log.Printf("Received signal \"%v\", shutting down.", s)
				devicePlugin.Stop()
				break L
		}
	}

}

