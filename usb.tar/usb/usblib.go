package usb

type USBDevice struct {
	VID int
	PID int
}
