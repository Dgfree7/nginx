package usb

import (
	"fmt"
	"reflect"
	"strings"
	"time"

	"k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/conversion"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/apimachinery/pkg/util/wait"
	clientset "k8s.io/client-go/kubernetes"
	nodeutil "k8s.io/kubernetes/pkg/util/node"

	"github.com/golang/glog"
)

var (
	// readonly
	oneInt64 int64 = 1
	deleteOpt = &metav1.DeleteOptions{GracePeriodSeconds: &oneInt64}
)

type usbManager struct {
	allUSBs  []*USBDevice
	duration time.Duration

	nodeName   types.NodeName
	kubeClient clientset.Interface
}

var _ USBManager = &usbManager{}

func NewUSBManager(nodeName types.NodeName, kubeClient clientset.Interface) USBManager {
	return &usbManager{
		nodeName:   nodeName,
		kubeClient: kubeClient,
		duration:   time.Second,
	}
}

func (m *usbManager) Start() error {
	go wait.Forever(m.loop, m.duration)
	glog.V(4).Info("Start USB Manager")
	return nil
}

func (m *usbManager) loop() {
	m.allUSBs = discoverUSBs()
	if err := m.advertiseResource(); err != nil {
		glog.Errorf("fail to advertise usb resource: %v", err)
	}

	if err := m.checkPods(); err != nil {
		glog.Errorf("fail to check pods for usb: %v", err)
	}
}

func (m *usbManager) advertiseResource() error {
	node, err := m.kubeClient.CoreV1().Nodes().Get(string(m.nodeName), metav1.GetOptions{})
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil
		}
		return err
	}

	clonedNode, err := conversion.NewCloner().DeepCopy(node)
	if err != nil {
		return fmt.Errorf("error clone node %q: %v", m.nodeName, err)
	}

	originalNode, ok := clonedNode.(*v1.Node)
	if !ok || originalNode == nil {
		return fmt.Errorf("failed to cast %q node object %#v to v1.Node", m.nodeName, clonedNode)
	}

	for resourceName := range node.Status.Capacity {
		if strings.HasPrefix(string(resourceName), ResourceUSBPrefix) {
			delete(node.Status.Capacity, resourceName)
		}
	}
	for _, usb := range m.allUSBs {
		resourceName := buildResourceName(usb)
		if quantity, ok := node.Status.Capacity[resourceName]; !ok {
			node.Status.Capacity[resourceName] = oneQuantity
		} else {
			quantity.Add(oneQuantity)
			node.Status.Capacity[resourceName] = quantity
		}
	}

	if reflect.DeepEqual(originalNode.Status.Capacity, node.Status.Capacity) {
		return nil
	}

	if _, err := nodeutil.PatchNodeStatus(m.kubeClient.CoreV1(), m.nodeName, originalNode, node); err != nil {
		return fmt.Errorf("Unable to reconcile node %q with API server: error updating node: %v", m.nodeName, err)
	}
	return nil
}

func (m *usbManager) checkPods() error {
	usbResourceSet := sets.String{}
	for _, usb := range m.allUSBs {
		usbResourceSet.Insert(string(buildResourceName(usb)))
	}

	selector := fmt.Sprintf("spec.nodeName==%s,status.phase!=%s", m.nodeName, v1.PodSucceeded)
	podList, err := m.kubeClient.CoreV1().Pods(v1.NamespaceAll).List(metav1.ListOptions{FieldSelector: selector})
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil
		}
		return err
	}

	podsToEvict := []v1.Pod{}

	for _, pod := range podList.Items {
		if isToEvictPod(pod, usbResourceSet) {
			podsToEvict = append(podsToEvict, pod)
		}
	}

	for _, pod := range podsToEvict {
		if err := m.kubeClient.CoreV1().Pods(pod.Namespace).Delete(pod.Name, deleteOpt); err != nil {
			glog.Errorf("fail to evict pod %v/%v: %v", pod.Namespace, pod.Name, err)
		}
	}
	return nil
}

func isToEvictPod(pod v1.Pod, usbs sets.String) bool {
	for _, ctn := range pod.Spec.Containers {
		for resourceName := range ctn.Resources.Requests {
			if isUSBResourceName(resourceName) && !usbs.Has(string(resourceName)) {
				return true
			}
		}
	}
	return false
}
