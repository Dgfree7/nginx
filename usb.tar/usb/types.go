package usb

type USBManager interface {
	// Start logically initializes USBManager
	Start() error
}
